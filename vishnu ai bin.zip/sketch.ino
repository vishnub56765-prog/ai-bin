#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <ESP32Servo.h>

// --- Pin Definitions ---
const int PIN_SERVO_PLASTIC = 18;
const int PIN_SERVO_PAPER   = 19;
const int PIN_SERVO_ORGANIC = 23;

const int PIN_LED_GREEN     = 25;
const int PIN_LED_YELLOW    = 26;
const int PIN_LED_RED       = 27;

const int PIN_BUZZER        = 32;

// --- Components Initialization ---
LiquidCrystal_I2C lcd(0x27, 16, 2); // Set LCD address to 0x27 for a 16x2 display

Servo servoPlastic;
Servo servoPaper;
Servo servoOrganic;

void setup() {
  // Initialize standard Serial monitor for testing inputs
  Serial.begin(115200);

  // Initialize LCD
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("System Ready");
  lcd.setCursor(0, 1);
  lcd.print("Type in Serial");

  // Initialize Servos (attach to pins and set initial position to 0 degrees)
  servoPlastic.attach(PIN_SERVO_PLASTIC);
  servoPaper.attach(PIN_SERVO_PAPER);
  servoOrganic.attach(PIN_SERVO_ORGANIC);
  
  servoPlastic.write(0);
  servoPaper.write(0);
  servoOrganic.write(0);

  // Initialize LEDs & Buzzer pins
  pinMode(PIN_LED_GREEN, OUTPUT);
  pinMode(PIN_LED_YELLOW, OUTPUT);
  pinMode(PIN_LED_RED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);

  // Startup test beep & lights
  digitalWrite(PIN_LED_GREEN, HIGH);
  digitalWrite(PIN_LED_YELLOW, HIGH);
  digitalWrite(PIN_LED_RED, HIGH);
  tone(PIN_BUZZER, 1000, 200);
  delay(500);
  digitalWrite(PIN_LED_GREEN, LOW);
  digitalWrite(PIN_LED_YELLOW, LOW);
  digitalWrite(PIN_LED_RED, LOW);
  
  Serial.println("\n--- System Initialized ---");
  Serial.println("Type 'plastic', 'paper', or 'organic' in the box above and click Send.");
}

void loop() {
  // Check if text is typed into the Serial Monitor
  if (Serial.available()) {
    String classification = Serial.readStringUntil('\n');
    classification.trim(); // Remove spaces/newlines

    Serial.print("Received input: ");
    Serial.println(classification);

    // Handle actions based on the input
    if (classification.equalsIgnoreCase("plastic")) {
      handlePlastic();
    } 
    else if (classification.equalsIgnoreCase("paper")) {
      handlePaper();
    } 
    else if (classification.equalsIgnoreCase("organic")) {
      handleOrganic();
    } 
    else {
      handleUnknown(classification);
    }
  }
}

// --- Action Handlers ---

void handlePlastic() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Item: PLASTIC");
  lcd.setCursor(0, 1);
  lcd.print("Sorting to Bin 1");

  digitalWrite(PIN_LED_GREEN, HIGH);
  tone(PIN_BUZZER, 1200, 100);

  // Actuate Plastic Servo
  servoPlastic.write(90);
  delay(1500);
  servoPlastic.write(0);

  digitalWrite(PIN_LED_GREEN, LOW);
  resetLCD();
}

void handlePaper() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Item: PAPER");
  lcd.setCursor(0, 1);
  lcd.print("Sorting to Bin 2");

  digitalWrite(PIN_LED_YELLOW, HIGH);
  tone(PIN_BUZZER, 1500, 100);

  // Actuate Paper Servo
  servoPaper.write(90);
  delay(1500);
  servoPaper.write(0);

  digitalWrite(PIN_LED_YELLOW, LOW);
  resetLCD();
}

void handleOrganic() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Item: ORGANIC");
  lcd.setCursor(0, 1);
  lcd.print("Sorting to Bin 3");

  digitalWrite(PIN_LED_RED, HIGH);
  tone(PIN_BUZZER, 1800, 100);

  // Actuate Organic Servo
  servoOrganic.write(90);
  delay(1500);
  servoOrganic.write(0);

  digitalWrite(PIN_LED_RED, LOW);
  resetLCD();
}

void handleUnknown(String result) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Unknown Command:");
  lcd.setCursor(0, 1);
  lcd.print(result);
  
  tone(PIN_BUZZER, 500, 300);
  delay(1500);
  resetLCD();
}

void resetLCD() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("System Ready");
  lcd.setCursor(0, 1);
  lcd.print("Type in Serial");
}